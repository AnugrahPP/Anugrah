﻿Imports System.Data.OleDb
Imports System.Data

Public Module VariableModule

    Public uname As String = ""
    Public pword As String = ""
    Public username As String = ""
    Public pass As String = ""
    Public Position As String

End Module
