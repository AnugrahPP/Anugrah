﻿Imports System.Data.OleDb
Imports System.Data

Public Class CustomerRegisterForm
    Private Sub RegisterBtnCR_Click(sender As Object, e As EventArgs) Handles RegisterBtnCR.Click
        If NameCRTB.Text = "" Or BDCRTB.Text = "" Or GenderCRTB.Text = "" Or AddressRTBCR.Text = "" Or UsernameTBCR.Text = "" Or PasswordTBCR1.Text = "" Or CPasswordTBCR1.Text = "" Then
            MsgBox("Please Fill the Required")
        Else
            Try
                Dim conn1 As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Windows 10\Documents\pelajaran\Visual Studio\FInalProject\Database3.mdb")
                Dim insert As String = "Insert into CustomerTable values ('" & NameCRTB.Text & "','" & BDCRTB.Text & "','" & GenderCRTB.Text & "','" & AddressRTBCR.Text & "','" & UsernameTBCR.Text & "', '" & PasswordTBCR1.Text & "', '" & StatusCB.Text & "');"
                Dim cmd1 As New OleDbCommand(insert, conn1)
                conn1.Open()
                cmd1.ExecuteNonQuery()
                MsgBox("Register success")
                LoginCustomerForm.Show()
                Me.Close()
            Catch ex As Exception
                MsgBox("Error")
            End Try
        End If
    End Sub

    Private Sub MaleRBCR_CheckedChanged(sender As Object, e As EventArgs) Handles MaleRBCR.CheckedChanged
        If MaleRBCR.Checked Then
            GenderCRTB.Text = MaleRBCR.Text
        End If
    End Sub

    Private Sub FemaleRBCR_CheckedChanged(sender As Object, e As EventArgs) Handles FemaleRBCR.CheckedChanged
        If FemaleRBCR.Checked Then
            GenderCRTB.Text = FemaleRBCR.Text
        End If
    End Sub

    Private Sub CPasswordTBCR1_TextChanged(sender As Object, e As EventArgs) Handles CPasswordTBCR1.TextChanged
        If Not CPasswordTBCR1.Text = PasswordTBCR1.Text Then
            Status.Text = "*Password not matched"
            Status.ForeColor = Color.Red
        Else
            Status.Text = "Password matched"
            Status.ForeColor = Color.Green
        End If
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        DateTimePicker1.Format = DateTimePickerFormat.Custom
        DateTimePicker1.CustomFormat = "yyyy-MM-dd"
        BDCRTB.Text = Format(DateTimePicker1.Value, "dd-MM-yyyy")
    End Sub
End Class