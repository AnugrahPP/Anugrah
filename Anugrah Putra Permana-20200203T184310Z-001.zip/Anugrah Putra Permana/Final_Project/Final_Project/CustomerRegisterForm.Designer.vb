﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class CustomerRegisterForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CustomerRegisterForm))
        Me.Label8 = New System.Windows.Forms.Label()
        Me.StatusCB = New System.Windows.Forms.ComboBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.RegisterBtnCR = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FemaleRBCR = New System.Windows.Forms.RadioButton()
        Me.MaleRBCR = New System.Windows.Forms.RadioButton()
        Me.CPasswordTBCR1 = New System.Windows.Forms.TextBox()
        Me.PasswordTBCR1 = New System.Windows.Forms.TextBox()
        Me.UsernameTBCR = New System.Windows.Forms.TextBox()
        Me.AddressRTBCR = New System.Windows.Forms.RichTextBox()
        Me.GenderCRTB = New System.Windows.Forms.TextBox()
        Me.BDCRTB = New System.Windows.Forms.TextBox()
        Me.NameCRTB = New System.Windows.Forms.TextBox()
        Me.Status = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(31, 313)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(37, 13)
        Me.Label8.TabIndex = 41
        Me.Label8.Text = "Status"
        '
        'StatusCB
        '
        Me.StatusCB.FormattingEnabled = True
        Me.StatusCB.Items.AddRange(New Object() {"Student", "Employee", "Other"})
        Me.StatusCB.Location = New System.Drawing.Point(102, 310)
        Me.StatusCB.Name = "StatusCB"
        Me.StatusCB.Size = New System.Drawing.Size(100, 21)
        Me.StatusCB.TabIndex = 40
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(255, 14)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(117, 83)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 39
        Me.PictureBox1.TabStop = False
        '
        'RegisterBtnCR
        '
        Me.RegisterBtnCR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.RegisterBtnCR.Location = New System.Drawing.Point(250, 211)
        Me.RegisterBtnCR.Name = "RegisterBtnCR"
        Me.RegisterBtnCR.Size = New System.Drawing.Size(120, 52)
        Me.RegisterBtnCR.TabIndex = 37
        Me.RegisterBtnCR.Text = "Register"
        Me.RegisterBtnCR.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(31, 271)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 26)
        Me.Label7.TabIndex = 36
        Me.Label7.Text = "Confirm " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Password"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(30, 245)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 13)
        Me.Label6.TabIndex = 35
        Me.Label6.Text = "Password"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 210)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 13)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "Username"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(30, 145)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(45, 13)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Address"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 109)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "Gender"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(31, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 13)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "Birth Date"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(30, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Name"
        '
        'FemaleRBCR
        '
        Me.FemaleRBCR.AutoSize = True
        Me.FemaleRBCR.Location = New System.Drawing.Point(269, 106)
        Me.FemaleRBCR.Name = "FemaleRBCR"
        Me.FemaleRBCR.Size = New System.Drawing.Size(59, 17)
        Me.FemaleRBCR.TabIndex = 29
        Me.FemaleRBCR.TabStop = True
        Me.FemaleRBCR.Text = "Female"
        Me.FemaleRBCR.UseVisualStyleBackColor = True
        '
        'MaleRBCR
        '
        Me.MaleRBCR.AutoSize = True
        Me.MaleRBCR.Location = New System.Drawing.Point(215, 106)
        Me.MaleRBCR.Name = "MaleRBCR"
        Me.MaleRBCR.Size = New System.Drawing.Size(48, 17)
        Me.MaleRBCR.TabIndex = 28
        Me.MaleRBCR.TabStop = True
        Me.MaleRBCR.Text = "Male"
        Me.MaleRBCR.UseVisualStyleBackColor = True
        '
        'CPasswordTBCR1
        '
        Me.CPasswordTBCR1.Location = New System.Drawing.Point(102, 277)
        Me.CPasswordTBCR1.Name = "CPasswordTBCR1"
        Me.CPasswordTBCR1.Size = New System.Drawing.Size(100, 20)
        Me.CPasswordTBCR1.TabIndex = 27
        Me.CPasswordTBCR1.UseSystemPasswordChar = True
        '
        'PasswordTBCR1
        '
        Me.PasswordTBCR1.Location = New System.Drawing.Point(102, 242)
        Me.PasswordTBCR1.Name = "PasswordTBCR1"
        Me.PasswordTBCR1.Size = New System.Drawing.Size(100, 20)
        Me.PasswordTBCR1.TabIndex = 26
        Me.PasswordTBCR1.UseSystemPasswordChar = True
        '
        'UsernameTBCR
        '
        Me.UsernameTBCR.Location = New System.Drawing.Point(102, 208)
        Me.UsernameTBCR.Name = "UsernameTBCR"
        Me.UsernameTBCR.Size = New System.Drawing.Size(100, 20)
        Me.UsernameTBCR.TabIndex = 25
        '
        'AddressRTBCR
        '
        Me.AddressRTBCR.Location = New System.Drawing.Point(102, 133)
        Me.AddressRTBCR.Name = "AddressRTBCR"
        Me.AddressRTBCR.Size = New System.Drawing.Size(186, 67)
        Me.AddressRTBCR.TabIndex = 24
        Me.AddressRTBCR.Text = ""
        '
        'GenderCRTB
        '
        Me.GenderCRTB.Location = New System.Drawing.Point(102, 106)
        Me.GenderCRTB.Name = "GenderCRTB"
        Me.GenderCRTB.ReadOnly = True
        Me.GenderCRTB.Size = New System.Drawing.Size(100, 20)
        Me.GenderCRTB.TabIndex = 23
        '
        'BDCRTB
        '
        Me.BDCRTB.Location = New System.Drawing.Point(102, 77)
        Me.BDCRTB.Name = "BDCRTB"
        Me.BDCRTB.ReadOnly = True
        Me.BDCRTB.Size = New System.Drawing.Size(98, 20)
        Me.BDCRTB.TabIndex = 22
        '
        'NameCRTB
        '
        Me.NameCRTB.Location = New System.Drawing.Point(102, 15)
        Me.NameCRTB.Name = "NameCRTB"
        Me.NameCRTB.Size = New System.Drawing.Size(100, 20)
        Me.NameCRTB.TabIndex = 21
        '
        'Status
        '
        Me.Status.AutoSize = True
        Me.Status.Location = New System.Drawing.Point(249, 280)
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(0, 13)
        Me.Status.TabIndex = 42
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(102, 53)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(100, 20)
        Me.DateTimePicker1.TabIndex = 43
        '
        'CustomerRegisterForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Aqua
        Me.ClientSize = New System.Drawing.Size(402, 344)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Status)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.StatusCB)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.RegisterBtnCR)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.FemaleRBCR)
        Me.Controls.Add(Me.MaleRBCR)
        Me.Controls.Add(Me.CPasswordTBCR1)
        Me.Controls.Add(Me.PasswordTBCR1)
        Me.Controls.Add(Me.UsernameTBCR)
        Me.Controls.Add(Me.AddressRTBCR)
        Me.Controls.Add(Me.GenderCRTB)
        Me.Controls.Add(Me.BDCRTB)
        Me.Controls.Add(Me.NameCRTB)
        Me.Name = "CustomerRegisterForm"
        Me.Text = "CustomerRegisterForm"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label8 As Label
    Friend WithEvents StatusCB As ComboBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents RegisterBtnCR As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents FemaleRBCR As RadioButton
    Friend WithEvents MaleRBCR As RadioButton
    Friend WithEvents CPasswordTBCR1 As TextBox
    Friend WithEvents PasswordTBCR1 As TextBox
    Friend WithEvents UsernameTBCR As TextBox
    Friend WithEvents AddressRTBCR As RichTextBox
    Friend WithEvents GenderCRTB As TextBox
    Friend WithEvents BDCRTB As TextBox
    Friend WithEvents NameCRTB As TextBox
    Friend WithEvents Status As Label
    Friend WithEvents DateTimePicker1 As DateTimePicker
End Class
