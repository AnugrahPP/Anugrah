﻿Imports System.Data.OleDb
Imports System.Data
Public Class ItemListViewForm
    Dim conn As New OleDbConnection

    Private Sub ItemListViewForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Windows 10\Documents\pelajaran\Visual Studio\FInalProject\Database3.mdb"
        conn.Open()
        Me.dataGridShow()

    End Sub

    Private Sub dataGridShow()
        Dim ds As New DataSet
        Dim dt As New DataTable
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter

        da = New OleDbDataAdapter("SELECT * FROM ItemTable", conn)
        da.Fill(dt)

        DataGridView1.DataSource = dt.DefaultView
        conn.Close()
    End Sub
End Class