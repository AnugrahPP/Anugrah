﻿Imports System.Data.OleDb
Imports System.Data

Public Class LoginCustomerForm

    Private Sub LoginBtn_Click_1(sender As Object, e As EventArgs) Handles LoginBtn.Click
        If UsernameTB.Text = "" Or PasswordTB.Text = "" Then
            MsgBox("Plz Fill All the info")
        Else
            uname = UsernameTB.Text
            pword = PasswordTB.Text
            Dim querry As String = "Select  Password From CustomerTable where Username = '" & uname & "';"
            Dim dbsource As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Windows 10\Documents\pelajaran\Visual Studio\FInalProject\Database3.mdb"
            Dim conn2 = New OleDbConnection(dbsource)
            Dim cmd2 As New OleDbCommand(querry, conn2)
            conn2.Open()

            Try
                pass = cmd2.ExecuteScalar.ToString
            Catch ex As Exception
                MsgBox("Username Doesn't Exist")
            End Try
            If (pword = pass) Then
                MsgBox("Login success")
                CustomerForm.Show()
                If CustomerForm.Visible Then
                    Me.Hide()
                End If
            Else
                MsgBox("login Failed")
                UsernameTB.Clear()
                PasswordTB.Clear()
            End If
        End If
    End Sub

    Private Sub Label1_Click_1(sender As Object, e As EventArgs) Handles Label1.Click
        CustomerRegisterForm.Show()
        Me.Hide()
    End Sub

    Private Sub ShowChB_CheckedChanged_1(sender As Object, e As EventArgs) Handles ShowChB.CheckedChanged
        If PasswordTB.UseSystemPasswordChar Then
            PasswordTB.UseSystemPasswordChar = False
        Else
            PasswordTB.UseSystemPasswordChar = True
        End If
    End Sub
End Class