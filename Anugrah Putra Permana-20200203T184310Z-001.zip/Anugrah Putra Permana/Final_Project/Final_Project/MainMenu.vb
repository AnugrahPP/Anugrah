﻿Public Class MainMenu
    Private Sub LoginToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoginToolStripMenuItem.Click
        LoginAdminForm.MdiParent = Me
        LoginAdminForm.Show()
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub MainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        DateTB.Text = DateTime.Now.ToString("dddddd dd/MM/yyyy")
        TimerTB.Text = DateTime.Now.ToString("HH:mm:ss")
        If ToolStripProgressBar1.Value <= ToolStripProgressBar1.Maximum - 1 Then
            ToolStripProgressBar1.Value += 3
            MenuStrip1.Enabled = False
        Else
            Timer1.Enabled = True
            MenuStrip1.Enabled = True
            Status.Text = "Online"
        End If
    End Sub

    Private Sub DateTB_TextChanged(sender As Object, e As EventArgs) Handles DateTB.TextChanged

    End Sub

    Private Sub CustomerLoginToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomerLoginToolStripMenuItem.Click
        LoginCustomerForm.MdiParent = Me
        LoginCustomerForm.Show()
    End Sub

    Private Sub TimerTB_TextChanged(sender As Object, e As EventArgs) Handles TimerTB.TextChanged

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        AboutForm.Show()
        Me.Hide()
    End Sub

    Private Sub OtherToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OtherToolStripMenuItem.Click
        OtherForm.MdiParent = Me
        OtherForm.Show()
    End Sub
End Class