﻿Public Class PrintingForm
    Private Sub PrintForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ContextMenuStrip = ContextMenuStrip1
        Timer1.Enabled = True
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        PrintForm1.Print()
    End Sub


    Private Sub Label16_Click(sender As Object, e As EventArgs) Handles Label16.Click

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Timer.Text = DateTime.Now.ToString("HH:mm:ss")
        DateLabel.Text = DateTime.Now.ToString("dddddd dd/MM/yyyy")
    End Sub
End Class