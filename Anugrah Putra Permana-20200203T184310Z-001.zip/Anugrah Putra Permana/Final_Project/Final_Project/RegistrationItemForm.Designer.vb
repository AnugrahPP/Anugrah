﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegisterItemForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RegisterItemForm))
        Me.RegisterBtn = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ManyTB = New System.Windows.Forms.TextBox()
        Me.CodeTB = New System.Windows.Forms.TextBox()
        Me.ItemTB = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AdminImage = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PriceTB = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ItemLIstToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserLabel = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.LogOut = New System.Windows.Forms.Label()
        CType(Me.AdminImage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'RegisterBtn
        '
        Me.RegisterBtn.BackColor = System.Drawing.Color.DarkTurquoise
        Me.RegisterBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.RegisterBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegisterBtn.Location = New System.Drawing.Point(254, 176)
        Me.RegisterBtn.Name = "RegisterBtn"
        Me.RegisterBtn.Size = New System.Drawing.Size(75, 33)
        Me.RegisterBtn.TabIndex = 19
        Me.RegisterBtn.Text = "Register"
        Me.RegisterBtn.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 189)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 20)
        Me.Label4.TabIndex = 18
        Me.Label4.Text = "How Many"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 152)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 20)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "ID Item"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 117)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 20)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Name Item"
        '
        'ManyTB
        '
        Me.ManyTB.BackColor = System.Drawing.Color.DarkOrange
        Me.ManyTB.Location = New System.Drawing.Point(106, 192)
        Me.ManyTB.Name = "ManyTB"
        Me.ManyTB.Size = New System.Drawing.Size(100, 20)
        Me.ManyTB.TabIndex = 15
        '
        'CodeTB
        '
        Me.CodeTB.BackColor = System.Drawing.Color.DarkOrange
        Me.CodeTB.Location = New System.Drawing.Point(106, 154)
        Me.CodeTB.Name = "CodeTB"
        Me.CodeTB.Size = New System.Drawing.Size(100, 20)
        Me.CodeTB.TabIndex = 14
        '
        'ItemTB
        '
        Me.ItemTB.BackColor = System.Drawing.Color.DarkOrange
        Me.ItemTB.Location = New System.Drawing.Point(106, 118)
        Me.ItemTB.Name = "ItemTB"
        Me.ItemTB.Size = New System.Drawing.Size(100, 20)
        Me.ItemTB.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(82, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 25)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "ADMIN "
        '
        'AdminImage
        '
        Me.AdminImage.Image = CType(resources.GetObject("AdminImage.Image"), System.Drawing.Image)
        Me.AdminImage.Location = New System.Drawing.Point(221, 25)
        Me.AdminImage.Name = "AdminImage"
        Me.AdminImage.Size = New System.Drawing.Size(141, 102)
        Me.AdminImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.AdminImage.TabIndex = 11
        Me.AdminImage.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 222)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 20)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Price/Item"
        '
        'PriceTB
        '
        Me.PriceTB.BackColor = System.Drawing.Color.DarkOrange
        Me.PriceTB.Location = New System.Drawing.Point(106, 224)
        Me.PriceTB.Name = "PriceTB"
        Me.PriceTB.Size = New System.Drawing.Size(100, 20)
        Me.PriceTB.TabIndex = 22
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ItemLIstToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(362, 24)
        Me.MenuStrip1.TabIndex = 23
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ItemLIstToolStripMenuItem
        '
        Me.ItemLIstToolStripMenuItem.Name = "ItemLIstToolStripMenuItem"
        Me.ItemLIstToolStripMenuItem.Size = New System.Drawing.Size(64, 20)
        Me.ItemLIstToolStripMenuItem.Text = "Item List"
        '
        'UserLabel
        '
        Me.UserLabel.AutoSize = True
        Me.UserLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserLabel.Location = New System.Drawing.Point(104, 77)
        Me.UserLabel.Name = "UserLabel"
        Me.UserLabel.Size = New System.Drawing.Size(0, 15)
        Me.UserLabel.TabIndex = 24
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(53, 255)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(259, 23)
        Me.ProgressBar1.Step = 100
        Me.ProgressBar1.TabIndex = 25
        '
        'LogOut
        '
        Me.LogOut.AutoSize = True
        Me.LogOut.Location = New System.Drawing.Point(269, 130)
        Me.LogOut.Name = "LogOut"
        Me.LogOut.Size = New System.Drawing.Size(45, 13)
        Me.LogOut.TabIndex = 26
        Me.LogOut.Text = "Log Out"
        '
        'RegisterItemForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Green
        Me.ClientSize = New System.Drawing.Size(362, 284)
        Me.Controls.Add(Me.LogOut)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.UserLabel)
        Me.Controls.Add(Me.PriceTB)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.RegisterBtn)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ManyTB)
        Me.Controls.Add(Me.CodeTB)
        Me.Controls.Add(Me.ItemTB)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.AdminImage)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "RegisterItemForm"
        Me.Text = "Register Item Form"
        CType(Me.AdminImage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RegisterBtn As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ManyTB As TextBox
    Friend WithEvents CodeTB As TextBox
    Friend WithEvents ItemTB As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents AdminImage As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PriceTB As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ItemLIstToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UserLabel As Label
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents LogOut As Label
End Class
