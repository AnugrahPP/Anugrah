﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OtherForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.sumBtn = New System.Windows.Forms.Button()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ItemList = New System.Windows.Forms.ListBox()
        Me.AddBtn = New System.Windows.Forms.Button()
        Me.sortBtn = New System.Windows.Forms.Button()
        Me.reverseBtn = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TextBox3)
        Me.TabPage2.Controls.Add(Me.TextBox2)
        Me.TabPage2.Controls.Add(Me.TextBox1)
        Me.TabPage2.Controls.Add(Me.sumBtn)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(238, 222)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Sum with Function"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Number 1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(159, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Number 2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 118)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Result :"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(24, 65)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(50, 20)
        Me.TextBox1.TabIndex = 3
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(161, 65)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(50, 20)
        Me.TextBox2.TabIndex = 4
        '
        'sumBtn
        '
        Me.sumBtn.Location = New System.Drawing.Point(75, 166)
        Me.sumBtn.Name = "sumBtn"
        Me.sumBtn.Size = New System.Drawing.Size(75, 23)
        Me.sumBtn.TabIndex = 6
        Me.sumBtn.Text = "SUM"
        Me.sumBtn.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(70, 115)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(53, 20)
        Me.TextBox3.TabIndex = 7
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.reverseBtn)
        Me.TabPage1.Controls.Add(Me.sortBtn)
        Me.TabPage1.Controls.Add(Me.AddBtn)
        Me.TabPage1.Controls.Add(Me.ItemList)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(238, 222)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Array & Looping"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'ItemList
        '
        Me.ItemList.FormattingEnabled = True
        Me.ItemList.Location = New System.Drawing.Point(6, 6)
        Me.ItemList.Name = "ItemList"
        Me.ItemList.Size = New System.Drawing.Size(120, 199)
        Me.ItemList.TabIndex = 0
        '
        'AddBtn
        '
        Me.AddBtn.Location = New System.Drawing.Point(132, 46)
        Me.AddBtn.Name = "AddBtn"
        Me.AddBtn.Size = New System.Drawing.Size(90, 23)
        Me.AddBtn.TabIndex = 1
        Me.AddBtn.Text = "Array Element"
        Me.AddBtn.UseVisualStyleBackColor = True
        '
        'sortBtn
        '
        Me.sortBtn.Location = New System.Drawing.Point(132, 88)
        Me.sortBtn.Name = "sortBtn"
        Me.sortBtn.Size = New System.Drawing.Size(90, 23)
        Me.sortBtn.TabIndex = 2
        Me.sortBtn.Text = "Sort Element"
        Me.sortBtn.UseVisualStyleBackColor = True
        '
        'reverseBtn
        '
        Me.reverseBtn.Location = New System.Drawing.Point(132, 128)
        Me.reverseBtn.Name = "reverseBtn"
        Me.reverseBtn.Size = New System.Drawing.Size(90, 23)
        Me.reverseBtn.TabIndex = 3
        Me.reverseBtn.Text = "Reverse Element"
        Me.reverseBtn.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(53, 24)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(246, 248)
        Me.TabControl1.TabIndex = 0
        '
        'OtherForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(673, 284)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "OtherForm"
        Me.Text = "OtherForm"
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents sumBtn As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents reverseBtn As Button
    Friend WithEvents sortBtn As Button
    Friend WithEvents AddBtn As Button
    Friend WithEvents ItemList As ListBox
    Friend WithEvents TabControl1 As TabControl
End Class
