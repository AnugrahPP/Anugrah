﻿Imports System.Data.OleDb
Imports System.Data

Public Class AdminRegisterForm
    Private Sub RegisterBtnCR_Click(sender As Object, e As EventArgs) Handles RegisterBtnCR.Click
        If NameCRTB.Text = "" Or BDCRTB.Text = "" Or GenderCRTB.Text = "" Or AddressRTBCR.Text = "" Or UsernameTBCR.Text = "" Or PasswordTBCR.Text = "" Or CPasswordTBCR.Text = "" Then
            MsgBox("Please Fill the Required")
        Else
            Try
                Dim conn1 As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Windows 10\Documents\pelajaran\Visual Studio\FInalProject\Database3.mdb")
                Dim insert As String = "Insert into AdminTable values ('" & NameCRTB.Text & "','" & BDCRTB.Text & "','" & GenderCRTB.Text & "','" & AddressRTBCR.Text & "','" & UsernameTBCR.Text & "', '" & PasswordTBCR.Text & "', '" & StatusCB.Text & "');"
                Dim cmd1 As New OleDbCommand(insert, conn1)
                conn1.Open()
                cmd1.ExecuteNonQuery()
                MsgBox("Register success")
                LoginAdminForm.Show()
                Me.Close()
            Catch ex As Exception
                MsgBox("Error")
            End Try
        End If
    End Sub

    Private Sub MaleRBCR_CheckedChanged(sender As Object, e As EventArgs) Handles MaleRBCR.CheckedChanged
        If MaleRBCR.Checked Then
            GenderCRTB.Text = MaleRBCR.Text
        End If
    End Sub

    Private Sub FemaleRBCR_CheckedChanged(sender As Object, e As EventArgs) Handles FemaleRBCR.CheckedChanged
        If FemaleRBCR.Checked Then
            GenderCRTB.Text = FemaleRBCR.Text
        End If
    End Sub

    Private Sub CPasswordTBCR_TextChanged(sender As Object, e As EventArgs) Handles CPasswordTBCR.TextChanged
        If Not CPasswordTBCR.Text = PasswordTBCR.Text Then
            LabelStatus.Text = "*Password not matched"
            LabelStatus.ForeColor = Color.Red
        Else
            LabelStatus.Text = "Password matched"
            LabelStatus.ForeColor = Color.Green
        End If
    End Sub

    Private Sub AdminRegisterForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

End Class