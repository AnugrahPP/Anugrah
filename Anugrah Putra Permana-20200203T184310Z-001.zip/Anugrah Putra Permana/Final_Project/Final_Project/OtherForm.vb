﻿Public Class OtherForm
    Private strItems(5) As String

    Private Sub AddBtn_Click(sender As Object, e As EventArgs) Handles AddBtn.Click
        ClearList()

        strItems(0) = "Beng-beng"
        strItems(1) = "Teh Pucuk"
        strItems(2) = "Lamp 25 Watt"
        strItems(3) = "Comb"
        strItems(4) = "Pencil 2B"
        strItems(5) = "Pencil 3B"

        For num As Integer = 0 To strItems.Length - 1
            ItemList.Items.Add(strItems(num))
        Next
    End Sub

    Private Sub ClearList()

        ItemList.Items.Clear()

    End Sub

    Private Sub sortBtn_Click(sender As Object, e As EventArgs) Handles sortBtn.Click
        ClearList()

        Array.Sort(strItems)
        For num As Integer = 0 To strItems.Length - 1
            ItemList.Items.Add(strItems(num))
        Next
    End Sub

    Private Sub reverseBtn_Click(sender As Object, e As EventArgs) Handles reverseBtn.Click
        ClearList()

        Array.Reverse(strItems)
        For num As Integer = 0 To strItems.Length - 1
            ItemList.Items.Add(strItems(num))
        Next
    End Sub

    Private Sub sumBtn_Click(sender As Object, e As EventArgs) Handles sumBtn.Click
        Dim num1 As Integer = CInt(TextBox1.Text)
        Dim num2 As Integer = CInt(TextBox2.Text)

        TextBox3.Text = ssum(num1, num2)
    End Sub

    Private Function ssum(ByVal num1 As Integer, ByVal num2 As Integer) As Integer
        Return num1 + num2
    End Function

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub
End Class