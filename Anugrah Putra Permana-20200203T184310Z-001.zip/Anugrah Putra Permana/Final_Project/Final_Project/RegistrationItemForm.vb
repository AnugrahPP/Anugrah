﻿Imports System.Data.OleDb
Imports System.Data

Public Class RegisterItemForm
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles RegisterBtn.Click
        If ItemTB.Text = "" Or CodeTB.Text = "" Or ManyTB.Text = "" Then
            MsgBox("Fill the box")
        Else
            Try
                Dim conn1 As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Windows 10\Documents\pelajaran\Visual Studio\FInalProject\Database3.mdb")
                Dim insert As String = "Insert into ItemTable values('" & ItemTB.Text & "','" & CodeTB.Text & "','" & ManyTB.Text & "','" & PriceTB.Text & "');"
                Dim cmd1 As New OleDbCommand(insert, conn1)
                conn1.Open()
                cmd1.ExecuteNonQuery()
                ProgressBar1.PerformStep()
                MsgBox("Register success")
                ItemTB.Text = ""
                CodeTB.Text = ""
                ManyTB.Text = ""
                PriceTB.Text = ""
                ProgressBar1.Value = 0
            Catch ex As Exception
                MsgBox("error")
            End Try
        End If
    End Sub

    Private Sub ItemLIstToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ItemLIstToolStripMenuItem.Click
        ItemListViewForm.show
    End Sub

    Private Sub ProgressBar1_Click(sender As Object, e As EventArgs) Handles ProgressBar1.Click

    End Sub

    Private Sub LogOut_Click(sender As Object, e As EventArgs) Handles LogOut.Click
        Me.Close()
        LoginAdminForm.Show()
    End Sub
End Class
