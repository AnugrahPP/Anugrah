﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LoginCustomerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim UsernameLabel As System.Windows.Forms.Label
        Dim PasswordLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(LoginCustomerForm))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.UsernameTB = New System.Windows.Forms.TextBox()
        Me.PasswordTB = New System.Windows.Forms.TextBox()
        Me.ShowChB = New System.Windows.Forms.CheckBox()
        Me.LoginBtn = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        UsernameLabel = New System.Windows.Forms.Label()
        PasswordLabel = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(161, 277)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 29
        Me.Label1.Text = "Sign Up"
        '
        'UsernameTB
        '
        Me.UsernameTB.Location = New System.Drawing.Point(127, 137)
        Me.UsernameTB.Name = "UsernameTB"
        Me.UsernameTB.Size = New System.Drawing.Size(125, 20)
        Me.UsernameTB.TabIndex = 28
        '
        'UsernameLabel
        '
        UsernameLabel.AutoSize = True
        UsernameLabel.Location = New System.Drawing.Point(162, 121)
        UsernameLabel.Name = "UsernameLabel"
        UsernameLabel.Size = New System.Drawing.Size(55, 13)
        UsernameLabel.TabIndex = 25
        UsernameLabel.Text = "Username"
        '
        'PasswordLabel
        '
        PasswordLabel.AutoSize = True
        PasswordLabel.Location = New System.Drawing.Point(164, 162)
        PasswordLabel.Name = "PasswordLabel"
        PasswordLabel.Size = New System.Drawing.Size(53, 13)
        PasswordLabel.TabIndex = 26
        PasswordLabel.Text = "Password"
        '
        'PasswordTB
        '
        Me.PasswordTB.Location = New System.Drawing.Point(127, 176)
        Me.PasswordTB.Name = "PasswordTB"
        Me.PasswordTB.Size = New System.Drawing.Size(125, 20)
        Me.PasswordTB.TabIndex = 27
        Me.PasswordTB.UseSystemPasswordChar = True
        '
        'ShowChB
        '
        Me.ShowChB.AutoSize = True
        Me.ShowChB.Location = New System.Drawing.Point(127, 208)
        Me.ShowChB.Name = "ShowChB"
        Me.ShowChB.Size = New System.Drawing.Size(102, 17)
        Me.ShowChB.TabIndex = 24
        Me.ShowChB.Text = "Show Password"
        Me.ShowChB.UseVisualStyleBackColor = True
        '
        'LoginBtn
        '
        Me.LoginBtn.BackColor = System.Drawing.Color.DarkOrange
        Me.LoginBtn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.LoginBtn.Location = New System.Drawing.Point(123, 231)
        Me.LoginBtn.Name = "LoginBtn"
        Me.LoginBtn.Size = New System.Drawing.Size(136, 43)
        Me.LoginBtn.TabIndex = 23
        Me.LoginBtn.Text = "Login"
        Me.LoginBtn.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(143, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(95, 95)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'LoginCustomerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(382, 311)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.UsernameTB)
        Me.Controls.Add(UsernameLabel)
        Me.Controls.Add(PasswordLabel)
        Me.Controls.Add(Me.PasswordTB)
        Me.Controls.Add(Me.ShowChB)
        Me.Controls.Add(Me.LoginBtn)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "LoginCustomerForm"
        Me.Text = "LoginCustomerForm"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents UsernameTB As TextBox
    Friend WithEvents PasswordTB As TextBox
    Friend WithEvents ShowChB As CheckBox
    Friend WithEvents LoginBtn As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
