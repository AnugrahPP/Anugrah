﻿Public Class AboutForm
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Static IM
        IM = IM + 1
        PictureBox1.Image = ImageList1.Images(IM)

        If IM = 3 Then
            IM = 0
        End If
    End Sub

    Private Sub CustomizeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomizeToolStripMenuItem.Click
        MainMenu.Show()
        Me.Close()
    End Sub

    Private Sub AboutForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class