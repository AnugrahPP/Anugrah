﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CustomerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Larutan Penyegar")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Teh Pucuk")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Beverage", New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2})
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Beng-Beng")
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Food", New System.Windows.Forms.TreeNode() {TreeNode4})
        Dim TreeNode6 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Lamp")
        Dim TreeNode7 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Comb")
        Dim TreeNode8 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Drawing Tools")
        Dim TreeNode9 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("TV")
        Dim TreeNode10 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Mouse")
        Dim TreeNode11 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Other", New System.Windows.Forms.TreeNode() {TreeNode6, TreeNode7, TreeNode8, TreeNode9, TreeNode10})
        Dim TreeNode12 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Item List", New System.Windows.Forms.TreeNode() {TreeNode3, TreeNode5, TreeNode11})
        Me.PriceTB = New System.Windows.Forms.TextBox()
        Me.ManyTB = New System.Windows.Forms.TextBox()
        Me.STTB = New System.Windows.Forms.TextBox()
        Me.TaxTB = New System.Windows.Forms.TextBox()
        Me.TotalTB = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NextBtn = New System.Windows.Forms.Button()
        Me.ItemCB = New System.Windows.Forms.ComboBox()
        Me.CheckIn = New System.Windows.Forms.GroupBox()
        Me.CheckOut = New System.Windows.Forms.GroupBox()
        Me.PrintBtn = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.CheckIn.SuspendLayout()
        Me.CheckOut.SuspendLayout()
        Me.SuspendLayout()
        '
        'PriceTB
        '
        Me.PriceTB.Location = New System.Drawing.Point(288, 83)
        Me.PriceTB.Name = "PriceTB"
        Me.PriceTB.ReadOnly = True
        Me.PriceTB.Size = New System.Drawing.Size(100, 20)
        Me.PriceTB.TabIndex = 1
        '
        'ManyTB
        '
        Me.ManyTB.Location = New System.Drawing.Point(288, 123)
        Me.ManyTB.Name = "ManyTB"
        Me.ManyTB.Size = New System.Drawing.Size(100, 20)
        Me.ManyTB.TabIndex = 2
        '
        'STTB
        '
        Me.STTB.Location = New System.Drawing.Point(288, 161)
        Me.STTB.Name = "STTB"
        Me.STTB.ReadOnly = True
        Me.STTB.Size = New System.Drawing.Size(100, 20)
        Me.STTB.TabIndex = 3
        '
        'TaxTB
        '
        Me.TaxTB.Location = New System.Drawing.Point(288, 206)
        Me.TaxTB.Name = "TaxTB"
        Me.TaxTB.ReadOnly = True
        Me.TaxTB.Size = New System.Drawing.Size(100, 20)
        Me.TaxTB.TabIndex = 4
        '
        'TotalTB
        '
        Me.TotalTB.Location = New System.Drawing.Point(288, 248)
        Me.TotalTB.Name = "TotalTB"
        Me.TotalTB.ReadOnly = True
        Me.TotalTB.Size = New System.Drawing.Size(100, 20)
        Me.TotalTB.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(155, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 18)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Name Item"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(155, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 18)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Price"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(155, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(108, 18)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Amount of Item"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(155, 160)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(71, 18)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Sub Total"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(155, 205)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(32, 18)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Tax"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(155, 250)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 18)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Total"
        '
        'NextBtn
        '
        Me.NextBtn.BackColor = System.Drawing.Color.Lime
        Me.NextBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NextBtn.Location = New System.Drawing.Point(210, 280)
        Me.NextBtn.Name = "NextBtn"
        Me.NextBtn.Size = New System.Drawing.Size(116, 48)
        Me.NextBtn.TabIndex = 12
        Me.NextBtn.Text = "Next"
        Me.NextBtn.UseVisualStyleBackColor = False
        '
        'ItemCB
        '
        Me.ItemCB.FormattingEnabled = True
        Me.ItemCB.Location = New System.Drawing.Point(288, 39)
        Me.ItemCB.Name = "ItemCB"
        Me.ItemCB.Size = New System.Drawing.Size(121, 21)
        Me.ItemCB.TabIndex = 14
        '
        'CheckIn
        '
        Me.CheckIn.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.CheckIn.Controls.Add(Me.NextBtn)
        Me.CheckIn.Location = New System.Drawing.Point(139, 12)
        Me.CheckIn.Name = "CheckIn"
        Me.CheckIn.Size = New System.Drawing.Size(326, 328)
        Me.CheckIn.TabIndex = 15
        Me.CheckIn.TabStop = False
        Me.CheckIn.Text = "Check In"
        '
        'CheckOut
        '
        Me.CheckOut.Controls.Add(Me.PrintBtn)
        Me.CheckOut.Controls.Add(Me.Label16)
        Me.CheckOut.Controls.Add(Me.Label15)
        Me.CheckOut.Controls.Add(Me.Label14)
        Me.CheckOut.Controls.Add(Me.Label13)
        Me.CheckOut.Controls.Add(Me.Label12)
        Me.CheckOut.Controls.Add(Me.Label11)
        Me.CheckOut.Controls.Add(Me.Label10)
        Me.CheckOut.Controls.Add(Me.Label9)
        Me.CheckOut.Controls.Add(Me.Label8)
        Me.CheckOut.Controls.Add(Me.Label7)
        Me.CheckOut.Location = New System.Drawing.Point(480, 12)
        Me.CheckOut.Name = "CheckOut"
        Me.CheckOut.Size = New System.Drawing.Size(326, 328)
        Me.CheckOut.TabIndex = 16
        Me.CheckOut.TabStop = False
        Me.CheckOut.Text = "Check Out"
        '
        'PrintBtn
        '
        Me.PrintBtn.BackColor = System.Drawing.Color.Lime
        Me.PrintBtn.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PrintBtn.Location = New System.Drawing.Point(111, 280)
        Me.PrintBtn.Name = "PrintBtn"
        Me.PrintBtn.Size = New System.Drawing.Size(116, 48)
        Me.PrintBtn.TabIndex = 13
        Me.PrintBtn.Text = "Print"
        Me.PrintBtn.UseVisualStyleBackColor = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(39, 238)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(46, 20)
        Me.Label16.TabIndex = 9
        Me.Label16.Text = "Total"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(40, 178)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(87, 16)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "*With Tax 6%"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(39, 128)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(66, 16)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "Sub Total"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(39, 82)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(122, 20)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "Amount Of Item"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(215, 238)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(0, 20)
        Me.Label12.TabIndex = 5
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(215, 172)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(0, 20)
        Me.Label11.TabIndex = 4
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(215, 128)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(0, 20)
        Me.Label10.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(215, 82)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(0, 20)
        Me.Label9.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(215, 30)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 20)
        Me.Label8.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(39, 27)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(113, 20)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Name Of Item"
        '
        'TreeView1
        '
        Me.TreeView1.Location = New System.Drawing.Point(12, 12)
        Me.TreeView1.Name = "TreeView1"
        TreeNode1.Name = "MNM01"
        TreeNode1.Text = "Larutan Penyegar"
        TreeNode2.Name = "MNM02"
        TreeNode2.Text = "Teh Pucuk"
        TreeNode3.Name = "MNM"
        TreeNode3.Text = "Beverage"
        TreeNode4.Name = "MKN01"
        TreeNode4.Text = "Beng-Beng"
        TreeNode5.Name = "MKN"
        TreeNode5.Text = "Food"
        TreeNode6.Name = "OT01"
        TreeNode6.Text = "Lamp"
        TreeNode7.Name = "OT02"
        TreeNode7.Text = "Comb"
        TreeNode8.Name = "OT03"
        TreeNode8.Text = "Drawing Tools"
        TreeNode9.Name = "OT04"
        TreeNode9.Text = "TV"
        TreeNode10.Name = "OT05"
        TreeNode10.Text = "Mouse"
        TreeNode11.Name = "Other"
        TreeNode11.Text = "Other"
        TreeNode12.Name = "Item_List"
        TreeNode12.Text = "Item List"
        Me.TreeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode12})
        Me.TreeView1.Size = New System.Drawing.Size(121, 328)
        Me.TreeView1.TabIndex = 17
        '
        'CustomerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(840, 352)
        Me.Controls.Add(Me.TreeView1)
        Me.Controls.Add(Me.CheckOut)
        Me.Controls.Add(Me.ItemCB)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TotalTB)
        Me.Controls.Add(Me.TaxTB)
        Me.Controls.Add(Me.STTB)
        Me.Controls.Add(Me.ManyTB)
        Me.Controls.Add(Me.PriceTB)
        Me.Controls.Add(Me.CheckIn)
        Me.Name = "CustomerForm"
        Me.Text = "CustomerForm"
        Me.CheckIn.ResumeLayout(False)
        Me.CheckOut.ResumeLayout(False)
        Me.CheckOut.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PriceTB As TextBox
    Friend WithEvents ManyTB As TextBox
    Friend WithEvents STTB As TextBox
    Friend WithEvents TaxTB As TextBox
    Friend WithEvents TotalTB As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents NextBtn As Button
    Friend WithEvents ItemCB As ComboBox
    Friend WithEvents CheckIn As GroupBox
    Friend WithEvents CheckOut As GroupBox
    Friend WithEvents TreeView1 As TreeView
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents PrintBtn As Button
End Class
