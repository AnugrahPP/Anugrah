﻿Imports System.Data.OleDb
Imports System.Data

Public Class CustomerForm
    Sub fillcombo()
        Dim query As String
        Dim dbsource As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Windows 10\Documents\pelajaran\Visual Studio\FInalProject\Database3.mdb"
        Dim con As New OleDbConnection(dbsource)
        Dim command As OleDbCommand
        Dim reader As OleDbDataReader

        con.Open()
        query = "select * from ItemTable"
        command = New OleDbCommand(query, con)
        reader = command.ExecuteReader()

        While (reader.Read())
            ItemCB.Items.Add(reader("Name_Item"))
        End While
        command.Dispose()
        reader.Close()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles NextBtn.Click
        If MsgBox("Are You Sure Want to Check Out : ", MsgBoxStyle.YesNo, "Confirmation") = MsgBoxResult.Yes Then
            Label7.Text = ItemCB.Text
            Label8.Text = PriceTB.Text
            Label9.Text = ManyTB.Text
            Label10.Text = STTB.Text
            Label11.Text = TaxTB.Text
            Label12.Text = TotalTB.Text
        End If
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ItemCB.SelectedIndexChanged
        Dim dbsource As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Windows 10\Documents\pelajaran\Visual Studio\FInalProject\Database3.mdb"
        Dim con As New OleDbConnection(dbsource)
        Dim reader As OleDbDataReader
        Dim query As String = "select * from ItemTable where Name_Item = '" & ItemCB.Text & "'"
        Dim command As New OleDbCommand
        con.Open()
        command.CommandText = query
        command.Connection = con
        reader = command.ExecuteReader
        If (reader.Read() = True) Then
            PriceTB.Text = (reader("Price"))
        End If
        command.Dispose()
        reader.Close()

    End Sub

    Private Sub CustomerForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.fillcombo()
    End Sub

    Private Sub STTB_TextChanged(sender As Object, e As EventArgs) Handles STTB.TextChanged
        STTB.Text = FormatCurrency(STTB.Text)
    End Sub

    Private Sub ManyTB_TextChanged(sender As Object, e As EventArgs) Handles ManyTB.TextChanged
        Try
            Dim SubTotal = (STTB.Text)
            Dim Price = PriceTB.Text
            Dim HowMuch = ManyTB.Text
            Dim Tax = TaxTB.Text
            Dim Total = TotalTB.Text

            SubTotal = Price * HowMuch
            STTB.Text = SubTotal

            Tax = SubTotal * (6 / 100)
            TaxTB.Text = Tax

            Total = CInt(SubTotal) + CInt(Tax)
            TotalTB.Text = Total
        Catch Ex As Exception
            ManyTB.Text = 1
        End Try
    End Sub

    Private Sub TaxTB_TextChanged(sender As Object, e As EventArgs) Handles TaxTB.TextChanged
        TaxTB.Text = FormatCurrency(TaxTB.Text)
    End Sub

    Private Sub PrintBtn_Click(sender As Object, e As EventArgs) Handles PrintBtn.Click
        PrintingForm.Label7.Text = Label7.Text
        PrintingForm.Label8.Text = Label8.Text
        PrintingForm.Label9.Text = Label9.Text
        PrintingForm.Label10.Text = Label10.Text
        PrintingForm.Label11.Text = Label11.Text
        PrintingForm.Label12.Text = Label12.Text
        PrintingForm.Show()
    End Sub

    Private Sub PriceTB_TextChanged(sender As Object, e As EventArgs) Handles PriceTB.TextChanged
        PriceTB.Text = FormatCurrency(PriceTB.Text)
    End Sub

    Private Sub TotalTB_TextChanged(sender As Object, e As EventArgs) Handles TotalTB.TextChanged
        TotalTB.Text = FormatCurrency(TotalTB.Text)
    End Sub
End Class